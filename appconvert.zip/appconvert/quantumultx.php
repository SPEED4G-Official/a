<?php
function buildVmess($users, $server)
{
    $config = [
        "vmess={$server['host']}:{$server['port']}",
        'method=chacha20-poly1305',
        "password={$users['uuid']}",
        'fast-open=true',
        'udp-relay=true',
        "tag={$server['name']}"
    ];

    if ($server['tls']) {
        if ($server['network'] === 'tcp')
            array_push($config, 'obfs=over-tls');
        if ($server['tls_settings']) {
            $tlsSettings = $server['tls_settings'];
            if (isset($tlsSettings['allowInsecure']) && !empty($tlsSettings['allowInsecure']))
                array_push($config, 'tls-verification=' . ($tlsSettings['allowInsecure'] ? 'false' : 'true'));
            if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
                $host = $tlsSettings['serverName'];
            } else {
                $host = $users['sni'];
            }
        }
    }
    if ($server['network'] === 'ws') {
        if ($server['tls'])
            array_push($config, 'obfs=wss');
        else
            array_push($config, 'obfs=ws');
        if ($server['network_settings']) {
            $wsSettings = $server['network_settings'];
            if (isset($wsSettings['path']) && !empty($wsSettings['path']))
                array_push($config, "obfs-uri={$wsSettings['path']}");
            if (isset($wsSettings['headers']['Host']) && !empty($wsSettings['headers']['Host']) && !isset($host) && empty($users['sni'])) {
                $host = $wsSettings['headers']['Host'];
            } else {
                $host = $users['sni'];
            }
        }
    }
    if (isset($host)) {
        array_push($config, "obfs-host={$host}");
    }

    $uri = implode(',', $config);
    $uri .= "\r\n";
    return $uri;
}

function buildTrojan($users, $server)
{
    if (!empty($server['server_name']) && empty($users['sni'])) {
        $sni = $server['server_name'];
    } else {
        $sni = $users['sni'];
    }
    $config = [
        "trojan={$server['host']}:{$server['port']}",
        "password={$users['uuid']}",
        'over-tls=true',
        $sni ? "tls-host={$sni}" : "",
        $server['allow_insecure'] ? 'tls-verification=false' : 'tls-verification=true',
        'fast-open=true',
        "udp-relay=" . ($server['udp_over_tcp'] ? "true" : "false"),
        "tag={$server['name']}"
    ];
    $config = array_filter($config);
    $uri = implode(',', $config);
    $uri .= "\r\n";
    return $uri;
}

$uri = '';
header("subscription-userinfo: upload={$user['u']}; download={$user['d']}; total={$user['total_data']}; expire={$user['expired_at']}");
foreach ($servers as $item) {
    if ($item['type'] === 'vmess') {
        $uri .= buildVmess($user, $item);
    }
    if ($item['type'] === 'trojan') {
        $uri .= buildTrojan($user, $item);
    }
}
echo base64_encode($uri);
