<?php

function buildVless($users, $server)
{
    $config = [
        "v" => "2",
        "ps" => $server['name'],
        "add" => $server['host'],
        "port" => (string) $server['port'],
        "id" => $users['uuid'],
        "aid" => (string) $server['alter_id'],
        "net" => $server['network'],
        "type" => "none",
        "host" => "",
        "path" => "",
        "tls" => $server['tls'] ? "tls" : "",
    ];

    if ($server['tls']) {
        if ($server['tls_settings']) {
            $tlsSettings = $server['tls_settings'];
            if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
                $config['sni'] = $tlsSettings['serverName'];
            } else {
                $config['sni'] = $users['sni'];
            }
        }
    }
    if ((string) $server['network'] === 'ws') {
        if (isset($server['network_settings'])) {
            $wsSettings = $server['network_settings'];
        }
        if (isset($wsSettings['path'])) {
            $config['path'] = $wsSettings['path'];

        }
        if (isset($wsSettings['headers']['Host']) && empty($users['sni'])) {
            $config['host'] = $wsSettings['headers']['Host'];
        } else {
            $config['host'] = $users['sni'];
        }
    }
    if ((string) $server['network'] === 'grpc') {
        $grpcSettings = $server['network_settings'];
        if (isset($grpcSettings['serviceName'])) {
            $config['path'] = $grpcSettings['serviceName'];
        }
    }

    $params = [
        'encryption' => 'none',
        'security' => $server['tls'] ? "tls" : "",
        'headerType' => 'none',
        'type' => $server['network']
    ];
    if ($server['tls']) {
        if ($server['tls_settings']) {
            $tlsSettings = $server['tls_settings'];
            if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
                $params['sni'] = $tlsSettings['serverName'];
            } else {
                $params['sni'] = $users['sni'];
            }
        }
    }
    if ((string) $server['network'] === 'ws') {
        if (isset($server['network_settings'])) {
            $wsSettings = $server['network_settings'];
        }
        if (isset($wsSettings['path'])) {
            $params['path'] = $wsSettings['path'];

        }
        if (isset($wsSettings['headers']['Host']) && empty($users['sni'])) {
            $params['host'] = $wsSettings['headers']['Host'];
        } else {
            $params['host'] = $users['sni'];
        }
    }
    return "vless://" . $users['uuid'] . "@" . $server['host'] . ":" . (string) $server['port'] . "?" . http_build_query($params) . "#" . rawurlencode($server['name']) . "\r\n";
}

function buildVmess($users, $server)
{
    $config = [
        "v" => "2",
        "ps" => $server['name'],
        "add" => $server['host'],
        "port" => (string) $server['port'],
        "id" => $users['uuid'],
        "aid" => (string) $server['alter_id'],
        "net" => $server['network'],
        "type" => "none",
        "host" => "",
        "path" => "",
        "tls" => $server['tls'] ? "tls" : "",
    ];

    if ($server['tls']) {
        if ($server['tls_settings']) {
            $tlsSettings = $server['tls_settings'];
            if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
                $config['sni'] = $tlsSettings['serverName'];
            } else {
                $config['sni'] = $users['sni'];
            }
        }
    }
    if ((string) $server['network'] === 'ws') {
        if (isset($server['network_settings'])) {
            $wsSettings = $server['network_settings'];
        }
        if (isset($wsSettings['path'])) {
            $config['path'] = $wsSettings['path'];
        }
        if (isset($wsSettings['headers']['Host']) && empty($users['sni'])) {
            $config['host'] = $wsSettings['headers']['Host'];
        } else {
            $config['host'] = $users['sni'];
        }
    }
    if ((string) $server['network'] === 'grpc') {
        $grpcSettings = $server['network_settings'];
        if (isset($grpcSettings['serviceName'])) {
            $config['path'] = $grpcSettings['serviceName'];
        }
    }
    return "vmess://" . base64_encode(json_encode($config)) . "\r\n";
}

function buildTrojan($users, $server)
{
    $name = rawurlencode($server['name']);
    if (!empty($server['server_name']) && empty($users['sni'])) {
        $peer = $server['server_name'];
        $sni = $server['server_name'];
    } else {
        $peer = $users['sni'];
        $sni = $users['sni'];
    }
    $data = [
        'allowInsecure' => $server['allow_insecure'],
        'peer' => $peer,
        'sni' => $sni
    ];

    if ($server['network'] === 'grpc') {
        if (isset($server['network_settings']['serviceName'])) {
            $data['type'] = 'grpc';
            $data['obfs'] = 'grpc';
            $data['serviceName'] = $server['network_settings']['serviceName'];
            $data['path'] = $server['network_settings']['serviceName'];
        }
    }

    if ($server['network'] === 'ws') {
        if (isset($server['network_settings']['path'])) {
            $data['type'] = 'web-socket';
            $data['obfs'] = "web-socket";
            $data['plugin'] = "obfs-local";
            $data['obfs-uri'] = $server['network_settings']['path'];
        }
    }
    $query = http_build_query($data);

    $uri = "trojan://{$users['uuid']}@{$server['host']}:{$server['port']}?{$query}#$name";
    $uri .= "\r\n";
    return $uri;
}
$uri = '';
foreach ($servers as $item) {
    if ($item['type'] === 'vless') {
        $uri .= buildVless($user, $item);
    }
    if ($item['type'] === 'vmess') {
        $uri .= buildVmess($user, $item);
    }
    if ($item['type'] === 'trojan') {
        $uri .= buildTrojan($user, $item);
    }
}

echo base64_encode($uri);