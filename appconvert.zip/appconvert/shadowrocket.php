<?php

function buildVless($users, $server)
{
    $config = [
        "v" => "2",
        "ps" => $server['name'],
        "add" => $server['host'],
        "port" => (string) $server['port'],
        "id" => $users['uuid'],
        "aid" => (string) $server['alter_id'],
        "net" => $server['network'],
        "type" => "none",
        "host" => "",
        "path" => "",
        "tls" => $server['tls'] ? "tls" : "",
    ];

    if ($server['tls']) {
        if ($server['tls_settings']) {
            $tlsSettings = $server['tls_settings'];
            $allowInsecure = (int) $tlsSettings['allowInsecure'];
            if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
                $config['sni'] = $tlsSettings['serverName'];
            } else {
                $config['sni'] = $users['sni'];
            }
        }
    } else {
        $allowInsecure = 0;
    }
    if ((string) $server['network'] === 'ws') {
        if (isset($server['network_settings'])) {
            $wsSettings = $server['network_settings'];
        }
        if (isset($wsSettings['path'])) {
            $config['path'] = $wsSettings['path'];

        }
        if (isset($wsSettings['headers']['Host']) && empty($users['sni'])) {
            $config['host'] = $wsSettings['headers']['Host'];
        } else {
            $config['host'] = $users['sni'];
        }
    }
    if ((string) $server['network'] === 'grpc') {
        $grpcSettings = $server['network_settings'];
        if (isset($grpcSettings['serviceName'])) {
            $config['path'] = $grpcSettings['serviceName'];
        }
    }
    $params = [
        'encryption' => 'none',
        'security' => $server['tls'] ? "tls" : "",
        'headerType' => 'none',
        'type' => $server['network'],
        'allowInsecure' => $allowInsecure,
    ];
    if ($server['tls']) {
        if ($server['tls_settings']) {
            $tlsSettings = $server['tls_settings'];
            if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
                $params['sni'] = $tlsSettings['serverName'];
            } else {
                $params['sni'] = $users['sni'];
            }
        }
    }
    if ((string) $server['network'] === 'ws') {
        if (isset($server['network_settings'])) {
            $wsSettings = $server['network_settings'];
        }
        if (isset($wsSettings['path'])) {
            $params['path'] = $wsSettings['path'];

        }
        if (isset($wsSettings['headers']['Host']) && empty($users['sni'])) {
            $params['host'] = $wsSettings['headers']['Host'];
        } else {
            $params['host'] = $users['sni'];
        }
    }
    return "vless://" . $users['uuid'] . "@" . $server['host'] . ":" . (string) $server['port'] . "?" . http_build_query($params) . "#" . rawurlencode($server['name']) . "\r\n";

}
function buildVmess($users, $server)
{
    $userinfo = base64_encode('auto:' . $users['uuid'] . '@' . $server['host'] . ':' . $server['port']);
    $config = [
        'tfo' => 1,
        'udp' => 1,
        'remark' => $server['name'],
        'alterId' => $server['alter_id']
    ];
    if ($server['tls']) {
        $config['tls'] = 1;
        if (isset($server['tls_settings'])) {
            $tlsSettings = $server['tls_settings'];
            if (isset($tlsSettings['allowInsecure'])) {
                $config['allowInsecure'] = (int) $tlsSettings['allowInsecure'];
            }
            if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
                $config['peer'] = $tlsSettings['serverName'];
            } else {
                $config['peer'] = $users['sni'];
            }
        }
    }
    if ($server['network'] === 'ws') {
        $config['obfs'] = "websocket";
        if (isset($server['network_settings'])) {
            $wsSettings = $server['network_settings'];
            if (isset($wsSettings['path']) && !empty($wsSettings['path'])) {
                $config['path'] = $wsSettings['path'];
            }
            if (isset($wsSettings['headers']['Host']) && !empty($wsSettings['headers']['Host']) && empty($users['sni'])) {
                $config['obfsParam'] = $wsSettings['headers']['Host'];
            } else {
                $config['obfsParam'] = $users['sni'];
            }
        }
    }
    if ($server['network'] === 'grpc') {
        $config['obfs'] = "grpc";
        if (isset($server['network_settings'])) {
            $grpcSettings = $server['network_settings'];
            if (isset($grpcSettings['serviceName'])) {
                $config['path'] = $grpcSettings['serviceName'];
            }
        }
        if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
            $config['host'] = $tlsSettings['serverName'];
        } else {
            $config['host'] = $users['sni'];
        }
    }
    $query = http_build_query($config, '', '&', PHP_QUERY_RFC3986);
    $uri = "vmess://$userinfo?$query";
    $uri .= "\r\n";
    return $uri;
}

function buildTrojan($users, $server)
{
    $name = rawurlencode($server['name']);
    if (!empty($server['server_name']) && empty($users['sni'])) {
        $peer = $server['server_name'];
    } else {
        $peer = $users['sni'];
    }
    $data = [
        'allowInsecure' => $server['allow_insecure'],
        'peer' => $peer,
        'udp' => 1
    ];

    if ($server['network'] === 'grpc') {
        if (isset($server['network_settings']['serviceName'])) {
            $data['obfs'] = 'grpc';
            $data['path'] = $server['network_settings']['serviceName'];
        }
    }

    if ($server['network'] === 'ws') {
        if (isset($server['network_settings']['path'])) {
            $data['obfs'] = 'websocket';
            $data['plugin'] = "obfs-local";
            $data['obfs-uri'] = $server['network_settings']['path'];
            $data['path'] = $server['network_settings']['path'];
        }

        if (isset($server['network_settings']['headers']['Host']) && empty($users['sni'])) {
            $data['obfsParam'] = $server['network_settings']['headers']['Host'];
        } else {
            $data['obfsParam'] = $users['sni'];
        }
    }

    $query = http_build_query($data);
    $uri = "trojan://{$users['uuid']}@{$server['host']}:{$server['port']}?$query&tfo=1#$name";
    $uri .= "\r\n";
    return $uri;
}

$uri = '';

$upload = round($user['u'] / (1024 * 1024 * 1024), 2);
$download = round($user['d'] / (1024 * 1024 * 1024), 2);
$sudung = $upload + $download;
$totalTraffic = round($user['transfer_enable_value'] / (1024 * 1024 * 1024), 2);
$tong = number_format($totalTraffic);
if ($user['expired_at'] === null) {
    $uri .= "STATUS=Đã Sử Dụng $sudung/$tong GB | HSD: Vĩnh Viễn\r\n";
} else {
    $expiredDate = date('d-m-Y', $user['expired_at']);
    $uri .= "STATUS=Đã Sử Dụng $sudung/$tong GB | HSD: $expiredDate\r\n";
}

foreach ($servers as $item) {

    if ($item['type'] === 'vless') {
        $uri .= buildVless($user, $item);
    }
    if ($item['type'] === 'vmess') {
        $uri .= buildVmess($user, $item);
    }
    if ($item['type'] === 'trojan') {
        $uri .= buildTrojan($user, $item);
    }
}
echo base64_encode($uri);

