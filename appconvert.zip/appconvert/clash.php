<?php

use Symfony\Component\Yaml\Yaml;

    function buildVmess($users, $server)
    {
        
        $array = [];
        $array['name'] = $server['name'];
        $array['type'] = 'vmess';
        $array['server'] = $server['host'];
        $array['port'] = $server['port'];
        $array['uuid'] = $users['uuid'];
        $array['alterId'] = $server['alter_id'];
        $array['cipher'] = 'auto';
        $array['udp'] = true;

        if ($server['tls']) {
            $array['tls'] = true;
            if (isset($server['tls_settings'])) {
                $tlsSettings = $server['tls_settings'];
                if (isset($tlsSettings['allowInsecure'])) {
                    $array['skip-cert-verify'] = (bool)$tlsSettings['allowInsecure'];
                }
                if (isset($tlsSettings['serverName']) && !empty($tlsSettings['serverName']) && empty($users['sni'])) {
                    $array['servername'] = $tlsSettings['serverName'];
                } else {
                    $array['servername'] = $users['sni'];
                }
            }
        }
        if ($server['network'] === 'ws') {
            $array['network'] = 'ws';
            if (isset($server['network_settings'])) {
                $wsSettings = $server['network_settings'];
                $array['ws-opts'] = [];
                if (!empty($wsSettings['path'])) {
                    $array['ws-opts']['path'] = $wsSettings['path'];
                }
                if (!empty($wsSettings['headers']['Host']) && empty($users['sni'])) {
                    $array['ws-opts']['headers'] = ['Host' => $wsSettings['headers']['Host']];
                } else {
                    $array['ws-opts']['headers'] = ['Host' => $users['sni']];
                }
            }
        }
        if ($server['network'] === 'grpc') {
            $array['network'] = 'grpc';
            if (isset($server['network_settings'])) {
                $grpcObject = $server['network_settings'];
                $array['grpc-opts'] = [];
                if (isset($grpcObject['serviceName'])) {
                    $array['grpc-opts']['grpc-service-name'] = $grpcObject['serviceName'];
                }
            }
        }
        return $array;
    }

    function buildTrojan($users, $server)
    {
        
        $array = [];
        $array['name'] = $server['name'];
        $array['type'] = 'trojan';
        $array['server'] = $server['host'];
        $array['port'] = $server['port'];
        $array['password'] = $users['uuid'];
        $array['udp'] = (boolean)$server['udp_over_tcp'];
        if (!empty($server['server_name']) && empty($users['sni'])) {
            $array['sni'] = $server['server_name'];
        } else {
            $array['sni'] = $users['sni'];
        }
        if (!empty($server['allow_insecure'])) {
            $array['skip-cert-verify'] = (bool)$server['allow_insecure'];
        }

        if ($server['network'] === 'grpc') {
            $array['network'] = $server['network'];
            if (isset($server['network_settings']['serviceName'])) {
                $array['grpc-opts'] = [];
                $array['grpc-opts']['grpc-service-name'] = $server['network_settings']['serviceName'];
            }
        }

        if ($server['network'] === 'ws') {
            $array['network'] = $server['network'];
            if (isset($server['network_settings']['path'])) {
                $array['ws-opts'] = [];
                $array['ws-opts'][] = $server['network_settings']['path'];
                if (isset($server['network_settings']['headers']) && is_array($server['network_settings']['headers'])) {
                    $array['ws-opts']['headers'] = $server['network_settings']['headers'];
                }
            }
        }
        return $array;
    }



        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        if ($userAgent && preg_match('/win/i', $userAgent)) {
            $appName = urlencode($NNL->site('tenweb'));
        } else {
            $appName = $NNL->site('tenweb');
        }

        header("subscription-userinfo: upload={$user['u']}; download={$user['d']}; total={$user['total_data']}; expire={$user['expired_at']}");
        header('profile-update-interval: 24');
        header("content-disposition:attachment; filename={$appName}");
        // header("profile-web-page-url:" . config('v2board.app_url'));

        $defaultConfig = __DIR__. '/../config/clash.yaml';

        $config = Yaml::parseFile($defaultConfig);
        $proxy = [];
        $proxies = [];

        foreach ($servers as $item) {

            if ($item['type'] === 'vmess') {
                array_push($proxy, buildVmess($user, $item));
                array_push($proxies, $item['name']);
            }
            if ($item['type'] === 'trojan') {
                array_push($proxy, buildTrojan($user, $item));
                array_push($proxies, $item['name']);
            }
        }

        $config['proxies'] = array_merge($config['proxies'] ?: [], $proxy);

        foreach ($config['proxy-groups'] as $k => $v) {
            if (!is_array($config['proxy-groups'][$k]['proxies'])) {
                continue;
            }
            $config['proxy-groups'][$k]['proxies'] = array_merge($config['proxy-groups'][$k]['proxies'], $proxies);
        }

        

        $yaml = Yaml::dump($config);

        echo str_replace('$app_name', $NNL->site('tenweb'), $yaml);